Panduan Penggunaan Aplikasi
---------------------------

Aplikasi ini digunakan untuk melakukan automation test pada website CURA Healthcare Service.
Automation test pada website ini mencakup:
1. Login (4 test case)
2. Booking Appointment (4 test case)
3. Logout (1 test case)

---------------------------

Untuk menjalankan test bisa di run melalui Test cases.
Deskripsi test bisa ditemukan di bagian properties

- Test cases
   - Assignment
      - Login
         - Login_01 >Run
         - Login_02 >Run
   
Hasil dari object test case tersimpan didalam Object Repository

